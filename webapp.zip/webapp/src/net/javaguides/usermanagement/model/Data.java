package net.javaguides.usermanagement.model;

import java.util.List;

public class Data {

	private String name;
	
	private List<Result> results;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Result> getResults() {
		return results;
	}

	public void setResults(List<Result> results) {
		this.results = results;
	}
	
	
}
