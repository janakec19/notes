package net.javaguides.usermanagement.model;

import java.util.List;

public class JsonResponse {

	private String query;
	
	private List<Data> data;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public List<Data> getData() {
		return data;
	}

	public void setData(List<Data> data) {
		this.data = data;
	}
}
