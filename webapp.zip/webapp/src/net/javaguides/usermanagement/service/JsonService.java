package net.javaguides.usermanagement.service;

import java.io.InputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

import net.javaguides.usermanagement.model.JsonResponse;

public class JsonService {

	public JsonResponse getJsonResponse() {
		try {
			InputStream inJson = JsonService.class.getResourceAsStream("sample.json");
			JsonResponse sample = new ObjectMapper().readValue(inJson, JsonResponse.class);
			return sample;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}
}
