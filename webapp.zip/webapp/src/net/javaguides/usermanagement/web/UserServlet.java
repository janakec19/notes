package net.javaguides.usermanagement.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import net.javaguides.usermanagement.model.Data;
import net.javaguides.usermanagement.model.JsonResponse;
import net.javaguides.usermanagement.service.JsonService;


@WebServlet("/")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private JsonService jsonService;

	private static Map<String, List<Data>> searchMap = new HashMap<>();

	public void init() {
		jsonService = new JsonService();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/search":
				showSearchResult(request, response);
				break;
			case "/qppscore":
				qppscore(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		JsonResponse josnResponse = jsonService.getJsonResponse();
		System.out.println(josnResponse.getQuery());
		searchMap.put(josnResponse.getQuery(), josnResponse.getData());
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}

	private void showSearchResult(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String search = request.getParameter("search");
		List<Data> data=null;
		if(search!=null && !search.isEmpty()) {
		data =searchMap.get(searchMap.keySet().toArray()[0]);
		}
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(data);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(json);
	}

	private void qppscore(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("qppscore.jsp");
		dispatcher.forward(request, response);

	}

}
